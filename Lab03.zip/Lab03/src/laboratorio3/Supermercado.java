
package laboratorio3;


public class Supermercado {
    private String nombre;
    private int codigo;
    private String gerente;
    private int total_ventas;

    public Supermercado(String nombre, int codigo, String gerente, int total_ventas) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.gerente = gerente;
        this.total_ventas = total_ventas;
    }
    public Supermercado(){}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getGerente() {
        return gerente;
    }

    public void setGerente(String gerente) {
        this.gerente = gerente;
    }

    public int getTotal_ventas() {
        return total_ventas;
    }

    public void setTotal_ventas(int total_ventas) {
        this.total_ventas = total_ventas;
    }
    




    
    
    


    
}
    
    
    
  

   
