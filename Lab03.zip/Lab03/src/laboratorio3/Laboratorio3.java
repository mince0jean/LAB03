
package laboratorio3;
import java.util.Scanner;

public class Laboratorio3 {

    
    public static void main(String[] args) {
        
        
        
        
        //------------------------------ I N S T A N C I A M O S   O B J E T O S ------------------------------
        Supermercado s = new Supermercado();
        Supermercado uno = new Supermercado("",0,"",0);
        Supermercado dos = new Supermercado("",0,"",0);
        Supermercado tres = new Supermercado("",0,"",0);
        Calcular c = new Calcular();
        Ventas one = new Ventas(0,0,0,0,0,0,0,0);
        Ventas two = new Ventas(0,0,0,0,0,0,0,0);
        Ventas three  = new Ventas(0,0,0,0,0,0,0,0);
        // ------------------------------ F I N   D E   I N S T A N C I  A R  ------------------------------

        
        //------------------------------ D E C L A R O    V A R I A B L E S ------------------------------ 
        int opcion;
     
        
        //------------------------------ F I N   D E    D E C L  A R A R    V A R I A B L E S ------------------------------
        
        Scanner leer = new Scanner(System.in);
        
        
        //------------------------------ S O L I C I T O    D A T O S  ------------------------------
            
            System.out.println(" para ingresar datos del primer supermercado presione 1: ");
            opcion = leer.nextInt();
            
            if(opcion == 1){
                System.out.println("Ingrese el nombre del supermercado: ");
                uno.setNombre(leer.next()); 
                System.out.println("Ingrese el codigo del supermercado ");
                uno.setCodigo(leer.nextInt());
                System.out.println("Ingrese el nombre del gerente: ");
                uno.setGerente(leer.next());
                
                System.out.println("Ingrese lo vendido del dia lunes: ");
                one.setVentas_lunes(leer.nextInt());
                
                System.out.println("Ingrese lo vendido del dia martes: ");
                one.setVentas_martes(leer.nextInt());
               
                System.out.println("Ingrese lo vendido del dia miercoles: ");
                one.setVentas_miercoles(leer.nextInt());
                
                System.out.println("Ingrese lo vendido del dia jueves: ");
                one.setVentas_jueves(leer.nextInt());
                
                System.out.println("Ingrese lo vendido del dia viernes: ");
                one.setVentas_viernes(leer.nextInt());
                
                System.out.println("Ingrese lo vendido del dia sabado: ");
                one.setVentas_sabado(leer.nextInt());
                
                System.out.println("Ingrese lo vendido del dia domingo: ");
                one.setVentas_domingo(leer.nextInt());
                
                int ventas_uno = one.getVentas_lunes() + one.getVentas_martes() + one.getVentas_miercoles() + one.getVentas_jueves() + one.getVentas_viernes() + one.getVentas_sabado() + one.getVentas_domingo() ;                
                uno.setTotal_ventas(ventas_uno);
                
            
            
                
                
            }
            System.out.println(" para ingresar datos del segundo supermercado presione 2: ");
            opcion = leer.nextInt();
            if(opcion == 2){
                System.out.println("Ingrese el nombre del supermercado: ");
                dos.setNombre(leer.next()); 
                System.out.println("Ingrese el codigo del supermercado ");
                dos.setCodigo(leer.nextInt());
                System.out.println("Ingrese el nombre del gerente: ");
                dos.setGerente(leer.next());
                
                System.out.println("Ingrese lo vendido del dia lunes: ");
                two.setVentas_lunes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia martes: ");
                two.setVentas_martes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia miercoles: ");
                two.setVentas_miercoles(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia jueves: ");
                two.setVentas_jueves(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia viernes: ");
                two.setVentas_viernes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia sabado: ");
                two.setVentas_sabado(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia domingo: ");
                two.setVentas_domingo(leer.nextInt());
                
                int ventas_dos = two.getVentas_lunes() + two.getVentas_martes() + two.getVentas_miercoles() + two.getVentas_jueves() + two.getVentas_viernes() + two.getVentas_sabado() + two.getVentas_domingo() ;
                dos.setTotal_ventas(ventas_dos);
                    
            }
            System.out.println(" para ingresar datos del tercer supermercado 3: ");
            opcion = leer.nextInt();
            if(opcion == 3){
                System.out.println("Ingrese el nombre del supermercado: ");
                tres.setNombre(leer.next()); 
                System.out.println("Ingrese el codigo del supermercado ");
                tres.setCodigo(leer.nextInt());
                System.out.println("Ingrese el nombre del gerente: ");
                tres.setGerente(leer.next());
                
                System.out.println("Ingrese lo vendido del dia lunes: ");
                three.setVentas_lunes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia martes: ");
                three.setVentas_martes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia miercoles: ");
                three.setVentas_miercoles(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia jueves: ");
                three.setVentas_jueves(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia viernes: ");
                three.setVentas_viernes(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia sabado: ");
                three.setVentas_sabado(leer.nextInt());
                System.out.println("Ingrese lo vendido del dia domingo: ");
                three.setVentas_domingo(leer.nextInt());
                
                int ventas = three.getVentas_lunes() + three.getVentas_martes() + three.getVentas_miercoles() + three.getVentas_jueves() + three.getVentas_viernes() + three.getVentas_sabado() + three.getVentas_domingo() ;
                tres.setTotal_ventas(ventas);
                
                

            }                 
           //------------------------------ F I N   D E    L A    S O L I C I T U D    D E D A T O S ------------------------------  
           
           
           
           
           //------------------------------ M O S T R A R    D A T O S ------------------------------
           System.out.println("--------------------------------");
           System.out.println("el supermercado " + uno.getNombre() + " con codigo " + uno.getCodigo() + " cuyo gerente " + uno.getGerente());
           System.out.println(" tuvo una venta semanal total de: " + uno.getTotal_ventas());
           System.out.println(" El porcentaje de venta por dia son: ");
           System.out.println("Lunes " + c.calculaPorcentaje(one.getVentas_lunes(),uno.getTotal_ventas())+ "%");
           System.out.println("Martes " + c.calculaPorcentaje(one.getVentas_martes(),uno.getTotal_ventas())+ "%");
           System.out.println("Miercoles " + c.calculaPorcentaje(one.getVentas_miercoles(),uno.getTotal_ventas())+ "%");
           System.out.println("Jueves " + c.calculaPorcentaje(one.getVentas_jueves(),uno.getTotal_ventas())+ "%");
           System.out.println("Viernes " + c.calculaPorcentaje(one.getVentas_viernes(),uno.getTotal_ventas())+ "%");
           System.out.println("Sabado " + c.calculaPorcentaje(one.getVentas_sabado(),uno.getTotal_ventas())+ "%");
           System.out.println("Domingo " + c.calculaPorcentaje(one.getVentas_domingo(),uno.getTotal_ventas())+ "%");
            
           System.out.println("--------------------------------");
           
           System.out.println(" el supermercado " + dos.getNombre() + " con codigo " + dos.getCodigo() + " cuyo gerente " + dos.getGerente());
           System.out.println(" tuvo una venta semanal total de: " + dos.getTotal_ventas());
           System.out.println("El porcentaje de venta por dia son: ");
           System.out.println("Lunes " + c.calculaPorcentaje(two.getVentas_lunes(),dos.getTotal_ventas())+ "%");
           System.out.println("Martes " + c.calculaPorcentaje(two.getVentas_martes(),dos.getTotal_ventas())+ "%");
           System.out.println("Miercoles " + c.calculaPorcentaje(two.getVentas_miercoles(),dos.getTotal_ventas())+ "%");
           System.out.println("Jueves " + c.calculaPorcentaje(two.getVentas_jueves(),dos.getTotal_ventas())+ "%");
           System.out.println("Viernes " + c.calculaPorcentaje(two.getVentas_viernes(),dos.getTotal_ventas())+ "%");
           System.out.println("Sabado " + c.calculaPorcentaje(two.getVentas_sabado(),dos.getTotal_ventas())+ "%");
           System.out.println("Domingo " + c.calculaPorcentaje(two.getVentas_domingo(),dos.getTotal_ventas())+ "%");
           
           System.out.println("--------------------------------");
           
           System.out.println(" el supermercado " + tres.getNombre() + " con codigo " +tres.getCodigo() + " cuyo gerente " + tres.getGerente());
           System.out.println(" tuvo una venta semanal total de: " + tres.getTotal_ventas());
           System.out.println(" El porcentaje de venta por dia son: ");
           System.out.println("Lunes " + c.calculaPorcentaje(three.getVentas_lunes(),tres.getTotal_ventas())+ "%");
           System.out.println("Martes " + c.calculaPorcentaje(three.getVentas_martes(),tres.getTotal_ventas())+ "%");
           System.out.println("Miercoles " + c.calculaPorcentaje(three.getVentas_miercoles(),tres.getTotal_ventas())+ "%");
           System.out.println("Jueves " + c.calculaPorcentaje(three.getVentas_jueves(),tres.getTotal_ventas())+ "%");
           System.out.println("Viernes " + c.calculaPorcentaje(three.getVentas_viernes(),tres.getTotal_ventas())+ "%");
           System.out.println("Sabado " + c.calculaPorcentaje(three.getVentas_sabado(),tres.getTotal_ventas())+ "%");
           System.out.println("Domingo " + c.calculaPorcentaje(three.getVentas_domingo(),tres.getTotal_ventas())+ "%");

           
        // ------------------------------ F I N   D E   M O S T R A R   D A T O S ------------------------------
        
        // ------------------------------ C O M P A R A D O R   D E   V E N T A S ------------------------------
        
           System.out.println("--------------------------------");
           int a = uno.getTotal_ventas();
           int b = dos.getTotal_ventas();
           int d = tres.getTotal_ventas();
           if (a< b&& a< d){
              System.out.println("El supermercado " + uno.getNombre() +" fue el que menos vendio ");
           }
           if (b< a && b< d){
              System.out.println("El supermercado " + dos.getNombre() +" fue el que menos vendio ");
           }
             
           if (d< a && d< b){
              System.out.println("El supermercado " + tres.getNombre() +" fue el que menos vendio ");
           }
        // ------------------------------ F I N   C O M P A R A C I O N   D E   V E N T A S ------------------------------
}            
}
