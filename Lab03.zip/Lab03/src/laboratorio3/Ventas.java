
package laboratorio3;

public class Ventas {
   private int ventas_lunes;
   private int ventas_martes;
   private int ventas_miercoles;
   private int ventas_jueves;
   private int ventas_viernes;
   private int ventas_sabado;
   private int ventas_domingo;
   private int venta_semanal;

    public Ventas(int ventas_lunes, int ventas_martes, int ventas_miercoles, int ventas_jueves, int ventas_viernes, int ventas_sabado, int ventas_domingo, int venta_semanal) {
        this.ventas_lunes = ventas_lunes;
        this.ventas_martes = ventas_martes;
        this.ventas_miercoles = ventas_miercoles;
        this.ventas_jueves = ventas_jueves;
        this.ventas_viernes = ventas_viernes;
        this.ventas_sabado = ventas_sabado;
        this.ventas_domingo = ventas_domingo;
        this.venta_semanal = venta_semanal;
    }




    public int getVentas_lunes() {
        return ventas_lunes;
    }

    public void setVentas_lunes(int ventas_lunes) {
        this.ventas_lunes = ventas_lunes;
    }

    public int getVentas_martes() {
        return ventas_martes;
    }

    public void setVentas_martes(int ventas_martes) {
        this.ventas_martes = ventas_martes;
    }

    public int getVentas_miercoles() {
        return ventas_miercoles;
    }

    public void setVentas_miercoles(int ventas_miercoles) {
        this.ventas_miercoles = ventas_miercoles;
    }

    public int getVentas_jueves() {
        return ventas_jueves;
    }

    public void setVentas_jueves(int ventas_jueves) {
        this.ventas_jueves = ventas_jueves;
    }

    public int getVentas_viernes() {
        return ventas_viernes;
    }

    public void setVentas_viernes(int ventas_viernes) {
        this.ventas_viernes = ventas_viernes;
    }

    public int getVentas_sabado() {
        return ventas_sabado;
    }

    public void setVentas_sabado(int ventas_sabado) {
        this.ventas_sabado = ventas_sabado;
    }

    public int getVentas_domingo() {
        return ventas_domingo;
    }

    public void setVentas_domingo(int ventas_domingo) {
        this.ventas_domingo = ventas_domingo;
    }

    public int getVenta_semanal() {
        return venta_semanal;
    }

    public void setVenta_semanal(int venta_semanal) {
        this.venta_semanal = venta_semanal;
    }


    
    
    


    


   
   
   
    
}
