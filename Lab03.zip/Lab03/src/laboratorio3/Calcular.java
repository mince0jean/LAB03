
package laboratorio3;
;




public class Calcular {



    
    
    
    public int calcula_venta_semanal(int lunes, int martes, int miercoles, int jueves, int viernes, int sabado, int domingo){
        return (lunes+martes+miercoles+jueves+viernes+sabado+domingo);
        
    }
    
    public double calculaPorcentaje(int dia, int semana){
        return ((100*dia)/semana); 
    }
    

    }
    
    
        
    
    
        
        
        

    

